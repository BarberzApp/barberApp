"use client"

import { motion } from "framer-motion"

export { motion }
