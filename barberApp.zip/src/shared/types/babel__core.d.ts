declare module '@babel/core' {
  export * from '@babel/core';
} 