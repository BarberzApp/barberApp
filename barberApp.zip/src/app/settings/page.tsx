'use client'

import { SettingsPage } from '@/features/settings/components/settings-page'
 
export default function Settings() {
  return <SettingsPage />
} 